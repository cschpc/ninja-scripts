#!/bin/bash
for n in 2 3
do
    cd L1_cube${n}
    echo "ElmerGrid 1 2 cube${n}.grd"
    ElmerGrid 1 2 cube${n}.grd
    echo "done serial"
    for i in 2 4 8 16 24 32 64
    do
	echo "ElmerGrid 1 2 cube${n}.grd -metis $i 4"
    	ElmerGrid 1 2 cube${n}.grd -metis $i 4
	echo "done $i"
    done
    cd ..
done
echo "all done"
