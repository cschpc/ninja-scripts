
#####################################################################################################
# Define code - please edit
#####################################################################################################
bin="/scratch/Elmer/bin/ElmerSolver_mpi"        # Binary name (with absolute path)
parameters=""              # Run parameters
testfolder="/scratch/zwinger/Elmer-KNL-Ninja/PoissonThreaded_orig"       # Folder where tests are stored (absolute path)
tests="L1_cube3"      # Name of test folders within testfolder (multiple allowes)

#Function get_perf() for computing performance (perf) and execution time
#(time). Executed in run folder
function get_perf()
{
    time=$(grep "ThreadedAssembly" out.txt| awk '{print $6}')
    perf=$(grep "ThreadedAssembly" out.txt| awk '{print $6/2.0620}')
}

#application specific env variables
#export A=b
#  perf=$(grep "ThreadedAssembly" out.txt| awk '{printf $6/0.6151}')
