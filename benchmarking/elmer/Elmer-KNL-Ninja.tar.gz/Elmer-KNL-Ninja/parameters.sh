#####################################################################################################
# Run parameters - please edit
#####################################################################################################
mpilibrary="intel"                            # MPI library, openmpi or intel

range_hyperthreads="1 2 4"                    # Numbr of threads per core
#range_hyperthreads="1"
range_processes="1 2 4 8 16 32 64"            # Number of processes (threads computed to fill cores)
#range_processes="1"
range_i_mpi_pin_order="compact"               # I_MPI_PIN_ORDER values
range_kmp_affinity="compact scatter balanced" # KMP_AFFINITY values
#range_kmp_affinity="compact"
#range_forcemcdram="0 1"                       # Force allocations to mcdram in flat mode. "0","1" or "0 1". 
range_forcemcdram="0"
                                              # If 1 it adds numactl commands (supports Quadrant, SNC-2, SNC-4)


#run parameters only applicable to singleparametersweep.sh. These are
#fixed, and one at a time loops through ranges

default_hyperthreads=4
default_processes=64
default_i_mpi_pin_order="compact"
default_kmp_affinity="compact" 
default_forcemcdram=0
